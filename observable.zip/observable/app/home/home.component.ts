import { Component, OnDestroy, OnInit } from '@angular/core';

import { Subscription, Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  private firstObsSubscription: Subscription;

  constructor() {
  }

  ngOnInit() {
    const customIntervalObservable: any = Observable.create((observer: any) => {
      let count = 0;
      setInterval(() => {
        observer.next(count); // next is emitting the value
        if (count === 8) {
          observer.complete(); // it says observable is completed successfully.
        }
        if (count > 10) {
          observer.error(new Error('Count is greater 3!')); // error
        }
        count++;
      }, 1000);
    });


    this.firstObsSubscription = customIntervalObservable.subscribe((data: any) => { // subscribe is to listen the emitted value
      console.log(data); // block handles emitted value
    }, (error: any) => {
      console.log(error); // block handles error case
      alert(error.message);
    }, () => {
      console.log('Completed!'); // block handles success case
    });
  }

  // It is a must to unsubscribe all the open subscription at the time of destroying the component
  // otherwise it will create a memory leak
  ngOnDestroy(): void {
    this.firstObsSubscription.unsubscribe(); 
  }

}
