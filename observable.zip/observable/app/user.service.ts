import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({providedIn: 'root'})
export class UserService {
  // activatedEmitter = new Subject<boolean>();
  activatedEmitter = new BehaviorSubject(false);
}
